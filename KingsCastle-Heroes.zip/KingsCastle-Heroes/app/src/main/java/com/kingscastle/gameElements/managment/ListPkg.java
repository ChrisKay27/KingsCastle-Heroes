package com.kingscastle.gameElements.managment;

public class ListPkg<T> {
	public T[] list;
	public int size;
}
