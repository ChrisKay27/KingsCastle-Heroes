package com.kingscastle.gameElements.spells;

public class ForceField {

}
