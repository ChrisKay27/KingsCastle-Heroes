package com.kingscastle.gameElements.livingThings.abilities;

public class AbilityTree {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
