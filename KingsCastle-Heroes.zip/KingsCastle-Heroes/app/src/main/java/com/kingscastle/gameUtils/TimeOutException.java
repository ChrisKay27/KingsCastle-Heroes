package com.kingscastle.gameUtils;

/**
 * Created by chris_000 on 7/4/2015.
 */
public class TimeOutException extends Exception {
}
