package com.kingscastle.gameElements.livingThings;

/**
 * Created by Chris on 9/7/2015 for KingsCastle-Heroes
 */
public class LivingThingListenerAdapter implements LivingThing.LivingThingListener {

    @Override
    public void onLevelUp(LivingThing lt) {
    }

    @Override
    public void onDeath(LivingThing lt) {
    }

    @Override
    public void onTargetSet(LivingThing forThis, LivingThing target) {
    }
}
