package com.kingscastle.gameUtils;

/**
 * Created by Chris on 7/17/2015 for Tower Defence
 */
public class NotAllowedInTowerDefenceException extends RuntimeException {
    public NotAllowedInTowerDefenceException(String msg) {
        super(msg);
    }
}
