package com.kingscastle.gameElements.livingThings.SoldierTypes;


import com.kingscastle.teams.Teams;

public abstract class BasicMageSoldier extends MageSoldier{

	public BasicMageSoldier() {
		super();
	}
	public BasicMageSoldier(Teams team) {
		super(team);
	}
}
