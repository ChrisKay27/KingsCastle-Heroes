package com.kingscastle.framework;

/**
 * Created by Chris on 7/11/2015 for TowerDefence
 */
public class DontUseThisMethodException extends Throwable {
    public DontUseThisMethodException(String s) {
        super(s);
    }
}
