package com.kingscastle.effects.animations;


import android.support.annotation.Nullable;

import com.kingscastle.framework.Image;

public class DeployFlag extends Anim
{
	@Nullable
    private static final Image flag = null;//l;Assets.loadImage(R.drawable.dest_flag);

	public DeployFlag()
	{
        throw new RuntimeException("Not Implemented");
		///setImage(flag);
	}


}
