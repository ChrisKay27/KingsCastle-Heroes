package com.kingscastle.gameElements.livingThings.buildings;


public class BuildingsUtil
{


}
