package com.kingscastle.framework;

public interface OnCompletionListener {

	void onTaskCompleted(boolean success);

}
