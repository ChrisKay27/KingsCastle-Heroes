package com.kingscastle.teams;


import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.kingscastle.gameElements.livingThings.LivingThing;
import com.kingscastle.gameElements.livingThings.buildings.Building;
import com.kingscastle.level.GridUtil;
import com.kingscastle.teams.races.Race;
import com.kingscastle.ui.UI;

import java.io.BufferedWriter;
import java.io.IOException;


public class HumanTeam extends Team
{

	private static final String TAG = "HumanTeam";

	public HumanTeam( Teams team , @NonNull HumanPlayer player, @NonNull Race race, GridUtil gUtil )
	{
		super( team, player, race, gUtil );
		maxWorkersAllowed = Integer.MAX_VALUE;
	}


	public void setUpListeners( @NonNull final UI ui ){


		addBcl(new OnBuildingCompleteListener() {
			@Override
			public void onBuildingComplete(@Nullable Building b) {
				if (b == null) return;
				if (b.isSelected()) {
					mm.getUI().setSelectedBuilding(b);
					ui.selUI.setSelected(b);
				}
			}
		});

		addBdl(new OnBuildingDestroyedListener() {
			@Override
			public void onBuildingDestroyed(@Nullable Building b) {
				if (b == null) return;

				if (b.isSelected())
					mm.getUI().setUnSelected(b);


			}
		});

		addUdl(new OnHumanoidDestroyedListener() {
			@Override
			public void onHumanoidDestroyed(@Nullable LivingThing lt) {
				if (lt == null) return;
				if (lt.isSelected())
					mm.getUI().setUnSelected(lt);


			}
		});
	}


	@Override
	public void saveYourself( @NonNull BufferedWriter b ) throws IOException
	{
		String s;

		Player p = getPlayer();

		String race = "";
		if( p != null )
			race = p.getRace().getRace().toString();


		wps = 0; fps = 0; gps = 0;buildingWorkers=0;


		s = "<Team name=\"" + getTeamName() + "\" t=\"H\" aicontrolled=\"false\" race=\"" + race + "\" tclvl=\""+getTcLevel()
				+"\" ww=\""+wps+"\" fw=\""+fps+"\" gw=\""+gps+"\" bw=\""+buildingWorkers+"\" >";
		b.write(s, 0, s.length());
		b.newLine();
		////Log.d( TAG , s);

		getPlayer().saveYourSelf(b);


		getArmyManager().saveYourSelf( b );
		getBm().saveYourSelf( b );

		//t.getPm().saveYourSelf( bw );
		//t.getSm().saveYourSelf( bw );

		s = "</Team>";

		b.write( s , 0 , s.length() );
		b.newLine();
	}







	@NonNull
    @Override
	public HumanPlayer getPlayer() {
		return (HumanPlayer) super.getPlayer();
	}








}
