package com.kingscastle.framework.implementation;

public interface MessageListener {

	public void receiveMessage(String msg);

}
