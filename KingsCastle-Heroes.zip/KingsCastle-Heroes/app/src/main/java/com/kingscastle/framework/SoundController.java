package com.kingscastle.framework;

public interface SoundController {
	void startMusic();
	void stopMusic();
}

