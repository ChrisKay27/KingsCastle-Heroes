package com.kingscastle.level;

/**
 * Created by Chris on 8/31/2015 for Heroes
 */
public class HeroesForestLevel extends HeroesLevel {




}
