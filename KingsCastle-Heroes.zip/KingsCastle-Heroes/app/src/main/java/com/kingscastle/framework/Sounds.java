package com.kingscastle.framework;


class Sounds {


	//public static Music theme;
	//public static ArrayList<Sound> unitSelectionSounds;
	//public static Sound mudStep;


	//	public static void playHumanoidSelectionSound()
	//	{
	//		//loadHumanoidSelectionSounds();
	//		//unitSelectionSounds.get((int) (Math.random()*unitSelectionSounds.size())).play(0.2f);
	//	}

	//	private static void loadHumanoidSelectionSounds()
	//	{
	//		if( unitSelectionSounds == null )
	//		{
	//			unitSelectionSounds = new ArrayList<Sound>();
	//			for( int i = 1 ; i < 36 ; i++ )
	//			{
	//				unitSelectionSounds.add(Rpg.getGame().getAudio().createSound("unitSelection/unitselection" + i +".wav"));
	//			}
	//		}
	//	}

	//	public static void playWalkingSound()
	//	{
	//		//loadMudStepSound();
	//
	//		//mudStep.play(0.05f);
	//	}
	//	private static void loadMudStepSound()
	//	{
	//		//if(mudStep==null){
	//		//	mudStep=Rpg.getGame().getAudio().createSound("walkingSounds/mud02.wav");
	//		//}
	//	}


}
