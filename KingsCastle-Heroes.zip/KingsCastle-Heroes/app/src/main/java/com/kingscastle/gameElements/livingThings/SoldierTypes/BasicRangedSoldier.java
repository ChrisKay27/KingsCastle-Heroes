package com.kingscastle.gameElements.livingThings.SoldierTypes;


import com.kingscastle.teams.Teams;

public abstract class BasicRangedSoldier extends RangedSoldier
{
	public BasicRangedSoldier() {
		super();
	}
	public BasicRangedSoldier(Teams team) {
		super(team);
	}


}
