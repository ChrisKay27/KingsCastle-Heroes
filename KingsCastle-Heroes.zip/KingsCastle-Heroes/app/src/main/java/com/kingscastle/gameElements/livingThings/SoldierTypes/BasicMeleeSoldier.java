package com.kingscastle.gameElements.livingThings.SoldierTypes;


import com.kingscastle.teams.Teams;

public abstract class BasicMeleeSoldier extends MeleeSoldier
{
	public BasicMeleeSoldier() {
		super();
	}
	public BasicMeleeSoldier(Teams team) {
		super(team);
	}


}
