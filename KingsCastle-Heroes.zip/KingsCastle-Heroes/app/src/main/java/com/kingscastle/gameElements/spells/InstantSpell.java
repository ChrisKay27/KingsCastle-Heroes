package com.kingscastle.gameElements.spells;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.kingscastle.framework.GameTime;
import com.kingscastle.framework.Input;
import com.kingscastle.gameElements.livingThings.Attributes;
import com.kingscastle.gameElements.livingThings.LivingThing;
import com.kingscastle.gameElements.managment.MM;

import org.jetbrains.annotations.NotNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;






public abstract class InstantSpell extends Spell {


	private long lastRefreshed = GameTime.getTime() + 999999,  //safe value
			startTime;
	private int refreshEvery = 9999, aliveTime = 0 ;





	@Override
	public boolean act()
	{
		////Log.d( "InstantSpell" , "act() , getLastRefreshed() =" + getLastRefreshed() + " , getRefreshEvery() = " + getRefreshEvery() );

		if( getLastRefreshed() + getRefreshEvery() < GameTime.getTime() )
		{
			refresh();
			setLastRefreshed(GameTime.getTime());
		}

		if( getAliveTime() == 0 )
		{
			if( getAnim() != null && getAnim().isOver() )
			{
				die();
				return true;
			}
		}
		else if( getStartTime() + getAliveTime() < GameTime.getTime() )
		{
			////Log.d( "InstantSpell" , "getStartTime() + getAliveTime() < GameTime.getTime()");
			die();
			return true;
		}

		return isDead();
	}



	void refresh() {

	}


	@Override
	public int calculateDamage()
	{
		if( getCaster() != null )
		{
			Attributes lq = getCaster().getLQ();

			return (int) (( getDamage() + (int) ( Math.random()*10 ) ) * lq.getBonuses().getDamageBonus() );
		}

		return 0;
	}


	void doDamage( @Nullable ArrayList<LivingThing> lts)
	{
		if( lts == null )
			return;


		for( LivingThing lt : lts )
			if( lt != null )
				lt.takeDamage( getDamage() , getCaster() );

	}




//	@Override
//	public boolean isDead()
//	{
//		if(getAnim() == null) {
//			return true;
//		}
//
//		return getAnim().isOver();
//	}





	@Override
	public void saveYourSelf( @NonNull BufferedWriter b) throws IOException
	{
		String s = "<"+this+" team=\""+ getTeamName() + "\" damage=\"" + getDamage() +
				"\" x=\"" + loc.getIntX() + "\" y=\"" + loc.getIntY() + "\"/>";

		b.write(s,0,s.length());
		b.newLine();
	}





	/**
	 * @return the lastRefreshed
	 */
	long getLastRefreshed() {
		return lastRefreshed;
	}

	/**
	 * @param lastRefreshed the lastRefreshed to set
	 */
	void setLastRefreshed(long lastRefreshed) {
		this.lastRefreshed = lastRefreshed;
	}

	/**
	 * @return the startTime
	 */
	long getStartTime() {
		return startTime;
	}

	/**
	 * @return the refreshEvery
	 */
	int getRefreshEvery() {
		return refreshEvery;
	}

	/**
	 * @return the aliveTime
	 */
	int getAliveTime() {
		return aliveTime;
	}





	/**
	 * @param startTime the startTime to set
	 */
	void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	/**
	 * @param refreshEvery the refreshEvery to set
	 */
	void setRefreshEvery(int refreshEvery) {
		this.refreshEvery = refreshEvery;
	}

	/**
	 * @param aliveTime the aliveTime to set
	 */
	void setAliveTime(int aliveTime) {
		this.aliveTime = aliveTime;
	}

	@Override
	public boolean analyseTouchEvent(@NotNull Input.TouchEvent event) {
		return false;
	}


	@Override
	public boolean cast(@NotNull @NonNull MM mm, @NotNull LivingThing target) {
		return false;
	}


    @Override
    public void undoAbility() {

    }
}
