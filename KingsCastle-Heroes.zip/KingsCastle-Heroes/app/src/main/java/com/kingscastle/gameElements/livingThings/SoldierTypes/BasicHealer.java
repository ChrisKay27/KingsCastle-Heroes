package com.kingscastle.gameElements.livingThings.SoldierTypes;


import com.kingscastle.teams.Teams;

public abstract class BasicHealer extends Healer
{

	public BasicHealer() {
		super();
	}
	public BasicHealer(Teams team) {
		super(team);
	}
}
